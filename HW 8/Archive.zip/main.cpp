//
//  main.cpp
//  HW 8
//
//  Created by Jayden Pereira on 11/22/18.
//  Copyright © 2018 Jayden Pereira. All rights reserved.
//

#include <iostream>
#include <fstream>
#include "ContactsBook.hpp" //class header
using namespace std;

int main() {
    //Initialize class variable
    ContactsBook key;
    
    //selector
    key.bookSelector();
}
